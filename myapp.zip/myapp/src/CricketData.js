const CricketData = [
  {
    id: 1,
    name: "SKY",
    category: "Batsman",
    details: "He is MR 360",
  },
  {
    id: 2,
    name: "Ishan Kishan",
    category: "Batsman",
    details: "Explosive batsman with a double century",
  },
  {
    id: 3,
    name: "Siraj",
    category: "Bowler",
    details: "fast bowler from Hyderabad",
  },
];

export default CricketData;
