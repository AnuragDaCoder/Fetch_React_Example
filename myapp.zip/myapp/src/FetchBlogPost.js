import React, { useEffect, useState } from "react";
import Table from "react-bootstrap/Table";
import "bootstrap/dist/css/bootstrap.min.css";

const myBlogPostUrl = "https://clientsidecoding.com/wp-json/wp/v2/posts";

const FetchBlogPost = () => {
  const [posts, SetPosts] = useState([]);

  const getLatestPosts = async () => {
    const response = await fetch(myBlogPostUrl);
    const blogPosts = await response.json();
    SetPosts(blogPosts);
  };

  useEffect(() => {
    getLatestPosts();
  }, []);

  return (
    <>
      <div className="myClass">
        <Table style={{ width: "700px" }} striped bordered hover size="sm" variant="dark">
          <thead>
            <tr>
              <td>Post</td>
              <td>Link</td>
            </tr>
          </thead>
          {posts.map((data) => {
            return (
              <tbody>
                <tr>
                  <td>{data.slug}</td>
                  <td>
                    <a target="_blank" href={data.link}>
                      {data.link}
                    </a>
                  </td>
                </tr>
              </tbody>
            );
          })}
        </Table>
      </div>
    </>
  );
};
export default FetchBlogPost;
